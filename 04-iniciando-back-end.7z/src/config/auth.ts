export default {
   jwt: {
     secret: 'bcfadfdb3208b8dac61a500231857f5b',
     expiresIn: '1d',
   },
};
